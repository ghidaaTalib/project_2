### Contribution Guide

- Feel free to contribute to this repo by raising the __pull request__
- Use the proper names for variable and functions
- Do not import libraries unless needed
- Test well before submitting the PR
